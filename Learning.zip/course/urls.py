
from django.urls import path
from .views import home
from .views import coursePage ,signup ,login , signout ,checkout

from django.conf import settings
from django.conf.urls.static import static
from ecomm.settings import MEDIA_ROOT,MEDIA_URL
from django.conf import settings
urlpatterns = [
    path('', home.as_view() , name='home'),
    path('course/<str:slug>', coursePage.as_view(),name="coursePage"),
    path('signup', signup.as_view(),name="signup"),
    path('login', login.as_view(),name="login"),
    path('logout', signout,name="logout"),
    path('check-out/<str:slug>', checkout.as_view() , name='checkout'),

]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
