from django.db import models
from django.db.models.fields import PositiveIntegerField

class Course(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100,null=False)
    description = models.CharField(max_length=200,null=False,default="")
    price = models.FloatField(null=False)
    discount = models.FloatField(null=False,default=0.0)
    is_active = models.BooleanField(default=False)
    date = models.DateTimeField(auto_now_add=True)
    thumbnail = models.ImageField(upload_to = "files/thumbnail")
    resource = models.FileField(upload_to = "files/resource")
    course_length = models.PositiveIntegerField(null=False)

    def __str__(self):
        return self.name

class CourseInfo(models.Model):
    description = models.CharField(max_length=400,null=False)
    course = models.ForeignKey(Course,null=False,on_delete=models.CASCADE)
    class Meta:
        abstract = True
class Tag(CourseInfo):
    pass

class Prerequisite(CourseInfo):
    pass

class Learning(CourseInfo):
    pass