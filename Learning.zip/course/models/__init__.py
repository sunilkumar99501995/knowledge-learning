from course.models.courses import Course, Tag, Learning,Prerequisite
from course.models.video import Video
from course.models.user_course import UserCourse
from course.models.payments import Payment

