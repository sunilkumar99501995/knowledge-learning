from django.contrib.admin.options import FORMFIELD_FOR_DBFIELD_DEFAULTS
from django.db import models
from course.models import UserCourse ,Course
from django.contrib.auth.models import  User

class Payment(models.Model):
    order_id = models.CharField(max_length=100 , null=False)
    payment_id = models.CharField(max_length=100)
    user_course = models.ForeignKey(UserCourse,null=False,on_delete=models.CASCADE)
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    course = models.ForeignKey(Course,on_delete=models.CASCADE)
    date = models.DateTimeField(auto_now_add=True)
    status = models.BooleanField(default=False)

    