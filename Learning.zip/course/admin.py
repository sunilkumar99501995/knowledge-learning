from django.contrib import admin
from django.db.models import fields
from course import models
# Register your models here.
from course.models import Course
from course.models import Tag,Learning,Prerequisite , Video , UserCourse ,Payment

class TagAdmin(admin.TabularInline):
    model = Tag

class LearningAdmin(admin.TabularInline):
    model = Learning

class PrerequisiteAdmin(admin.TabularInline):
    model= Prerequisite

class VideoAdmin(admin.TabularInline):
    model= Video

class CourseAdmin(admin.ModelAdmin):
    inlines = [TagAdmin,LearningAdmin,PrerequisiteAdmin,VideoAdmin]


admin.site.register(UserCourse)
admin.site.register(Payment)
admin.site.register(Course,CourseAdmin)

