from django import template
import math
register = template.Library()


@register.simple_tag
def price_calu(price , discount):
    if discount is None:
        return math.floor(price)
    else:
        return math.floor(price - (price*discount*0.01))


@register.filter
def rupee(price):
    return f"₹{price}"