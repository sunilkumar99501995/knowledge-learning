from django.contrib.auth import logout
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from django.views import View
from course.forms import RegistrationForm , LoginForm


class signup(View):
    def get(self,request):
        form = RegistrationForm()
        return render(request,"course/signup.html",context={'form':form})

    def post(self,request):
        form = RegistrationForm(request.POST)
        # print(form)
        if form.is_valid():
            user = form.save()
            if user:
                return redirect("login")
            
        return render(request,"course/signup.html",context={'form':form})





class login(View):
    def get(self,request):
        form =LoginForm()
        return render(request,"course/login.html",context={'form':form})

    def post(self,request):
        form = LoginForm(request=request,data = request.POST)
        if form.is_valid():
            # return HttpResponse("success login");
            return redirect('home')
        form =LoginForm()
        return render(request,"course/login.html",context={'form':form})
        
def signout(request):
    logout(request)
    return redirect('home')
