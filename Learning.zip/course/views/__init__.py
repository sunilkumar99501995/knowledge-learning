from course.views.homepage import home
from course.views.courses import coursePage
from course.views.checkout import checkout

from course.views.auth import signup , login , signout

