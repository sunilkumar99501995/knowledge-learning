from django.shortcuts import render
from django.views import View
from  course.models import Course,Tag,Learning,Prerequisite,Video


class home(View):
    def get(self,request):
        course = Course.objects.all()
        context = {'course':course}
        return render(request , "course/home.html",context=context)
