from django.shortcuts import redirect,render
from django.views import View
from course.models  import Course

class checkout(View):
    def get(self,request,slug):
        course = Course.objects.get(slug = slug)

        if request.user.is_authenticated is False:
            return redirect('login')
        
        context = {
            'course':course
        }

        return render(request ,template_name='course/check-out.html',context=context)
