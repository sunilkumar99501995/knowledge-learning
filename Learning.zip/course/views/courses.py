from django.http.response import HttpResponse
from django.shortcuts import render,redirect
from django.views import View
from  course.models import Course,Tag,Learning,Prerequisite,Video, video


class coursePage(View):
    def get(self,request,slug):
        print(request.user.is_authenticated)
        course = Course.objects.get(slug=slug)
        serial_number = request.GET.get('lecture')
        videos = course.video_set.all().order_by('serial_number')

        if serial_number is None:
            serial_number=1
        videoLink = Video.objects.get(course = course , serial_number = serial_number)
        if request.user.is_authenticated is False and videoLink.is_preview == False:
            return redirect("login")

        # print(video)
        # print(serial_number)
        context ={
            'course':course,
            'videoLink':videoLink,
            'videos':videos
        }
        return render(request , template_name="course/course_page.html",context=context)
